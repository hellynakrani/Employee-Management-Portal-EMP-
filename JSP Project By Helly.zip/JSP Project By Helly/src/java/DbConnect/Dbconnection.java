    /*
     * To change this license header, choose License Headers in Project Properties.
     * To change this template file, choose Tools | Templates
     * and open the template in the editor.
     */
    package DbConnect;

    /**
     *
     * @author mgs
     */
    import java.sql.*;

    public class Dbconnection {

        Connection Conn = null;
        Statement Stmt = null;
        ResultSet Rs = null;

        public Dbconnection() {
            try {
                Class.forName("com.mysql.jdbc.Driver");
                Conn = DriverManager.getConnection("jdbc:mysql://localhost:3307/helly?zeroDateTimeBehavior=convertToNull", "root", "root");
                Stmt = Conn.createStatement();
                Rs = Stmt.executeQuery("select * from empp1");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        public boolean AddRecord(String ENO, String EName, String Job, float Sa) {
            boolean success = false;
            try {
                String Query = "insert into empp1 (Empno, EName, Job, Salary) values("+ENO+", '"+ EName + "',  '" + Job + "', " + Sa + ")";;
                System.out.println(Query);
                int i = Stmt.executeUpdate(Query);
                if (i >= 1) {
                    success = true;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return success;
        }

        public ResultSet GetSingleRecord(int Eno) {
            ResultSet R1 = null;
            try {
                R1 = Stmt.executeQuery("Select * from empp1 where EmpNo = " + Eno);
            } catch (Exception e) {
                e.printStackTrace();
            }

            return R1;
        }

        public boolean DeleteRecord(int Eno) {
            boolean success = false;
            try {
                String Query = "Delete from empp1 where EmpNo = " + Eno;
                System.out.println(Query);
                int i = Stmt.executeUpdate(Query);
                if (i >= 1) {
                    success = true;
                } else {
                    success = false;
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
            return success;
        }

        public boolean UpdateRecord(String ENO, String EName, String Job, float Sa) {
            boolean success = false;
            try {
                String Query = "Update empp1 Set EName= '" + EName + "',  Job='" + Job + "', Salary=" + Sa + " where EmpNo=" + ENO;
                System.out.println(Query);
                int i = Stmt.executeUpdate(Query);
                if (i >= 1) {
                    success = true;
                } else {
                    success = false;
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
            return success;
        }

        public boolean AddRecord(String EName, String Job, float Sa) {
            boolean success = false;
            try {
                String Query = "insert into empp1 (Name,Job,Salary) values('" + EName + "','" + Job + "'," + Sa + ")";
                System.out.println(Query);
                int i = Stmt.executeUpdate(Query);
                if (i >= 1) {
                    success = true;
                } else {
                    success = false;
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
            return success;
        }

        public ResultSet GetEmpAll() {
            try {
                Rs = Stmt.executeQuery("select * from empp1");

            } catch (Exception e) {
                e.printStackTrace();
            }
            return Rs;
        }
    }
